# PdM 
Predictive Maintenance Multiclass and Multilabel code for this video:
https://www.youtube.com/watch?v=ZhXqXPyVKZU
